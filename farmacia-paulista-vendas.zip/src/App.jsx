import React, { useEffect, useState } from "react";
import { db } from "./firebase";
import { collection, getDocs } from "firebase/firestore";

export default function App() {
  const [produtos, setProdutos] = useState([]);
  const [carrinho, setCarrinho] = useState([]);

  useEffect(() => {
    const carregarProdutos = async () => {
      const snapshot = await getDocs(collection(db, "produtos"));
      const lista = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setProdutos(lista);
    };
    carregarProdutos();
  }, []);

  const adicionarAoCarrinho = (produto) => {
    setCarrinho((prev) => {
      const existente = prev.find((p) => p.id === produto.id);
      if (existente) {
        return prev.map((p) =>
          p.id === produto.id ? { ...p, quantidade: p.quantidade + 1 } : p
        );
      } else {
        return [...prev, { ...produto, quantidade: 1 }];
      }
    });
  };

  const calcularTotal = () =>
    carrinho.reduce((total, item) => total + item.preco * item.quantidade, 0);

  const gerarMensagemWhatsapp = () => {
    if (carrinho.length === 0) return;
    const mensagem = carrinho
      .map(
        (item) =>
          `- ${item.quantidade}x ${item.nome} – R$ ${item.preco.toFixed(2)}`
      )
      .join("\n");
    const total = calcularTotal().toFixed(2);
    const texto = `Olá! Gostaria de fazer um pedido:\n${mensagem}\nTotal: R$ ${total}`;
    const url = `https://wa.me/551733647300?text=${encodeURIComponent(texto)}`;
    window.open(url, "_blank");
  };

  return (
    <div className="p-6 bg-blue-50 min-h-screen">
      <h1 className="text-3xl font-bold text-blue-700 mb-6">
        Promoções em Higiene Bucal
      </h1>

      {carrinho.length > 0 && (
        <div className="bg-white p-4 mb-6 shadow rounded-xl border border-gray-200">
          <h2 className="text-xl font-semibold mb-2">🛒 Carrinho</h2>
          <ul className="mb-2">
            {carrinho.map((item) => (
              <li key={item.id}>
                {item.quantidade}x {item.nome} – R$ {(item.preco * item.quantidade).toFixed(2)}
              </li>
            ))}
          </ul>
          <p className="font-bold">Total: R$ {calcularTotal().toFixed(2)}</p>
          <button
            onClick={gerarMensagemWhatsapp}
            className="mt-3 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg font-semibold"
          >
            Finalizar Pedido no WhatsApp
          </button>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {produtos.map((produto) => (
          <div
            key={produto.id}
            className="bg-white rounded-2xl border shadow p-4 flex flex-col"
          >
            <img
              src={produto.imagem}
              alt={produto.nome}
              className="h-40 object-contain mb-4"
            />
            <h3 className="font-semibold text-lg">{produto.nome}</h3>
            <p className="text-blue-600 font-bold text-xl mt-2">
              R$ {produto.preco.toFixed(2)}
            </p>
            <button
              onClick={() => adicionarAoCarrinho(produto)}
              className="mt-auto bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 rounded-lg mt-4"
            >
              Comprar
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}